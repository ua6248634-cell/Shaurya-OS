#!/bin/bash
# ╔══════════════════════════════════════════════════════════════════╗
# ║  SHAURYA OS v1.0 — Build Script                                ║
# ║  Created by: Usman Ahmad                                        ║
# ║  Login: shaurya / usman141093                                  ║
# ╚══════════════════════════════════════════════════════════════════╝
set -e
RED='\033[0;31m'; GRN='\033[0;32m'; YLW='\033[1;33m'
ORAN='\033[0;33m'; CYAN='\033[0;36m'; NC='\033[0m'

echo -e "${CYAN}"
cat << 'BANNER'
  ███████╗██╗  ██╗ █████╗ ██╗   ██╗██████╗ ██╗   ██╗ █████╗
  ██╔════╝██║  ██║██╔══██╗██║   ██║██╔══██╗╚██╗ ██╔╝██╔══██╗
  ███████╗███████║███████║██║   ██║██████╔╝ ╚████╔╝ ███████║
  ╚════██║██╔══██║██╔══██║██║   ██║██╔══██╗  ╚██╔╝  ██╔══██║
  ███████║██║  ██║██║  ██║╚██████╔╝██║  ██║   ██║   ██║  ██║
  ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝
BANNER
echo -e "${YLW}  ⚔️  Shaurya OS v1.0 — Advanced Cyber Warfare Platform${NC}"
echo -e "${CYAN}  Created by Usman Ahmad — Courage in Every Byte${NC}"
echo ""

# ── Path safety ────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" 2>/dev/null && pwd)"
cd "$SCRIPT_DIR"
BUILD_DIR="$(pwd)"

if echo "$BUILD_DIR" | grep -q ' '; then
    echo -e "${ORAN}[!] Space in path — copying to /tmp/shaurya-build${NC}"
    SAFE="/tmp/shaurya-build"
    rm -rf "$SAFE"
    cp -r "$BUILD_DIR" "$SAFE"
    cd "$SAFE"
    BUILD_DIR="$(pwd)"
    echo -e "${GRN}[✓] Safe path: $BUILD_DIR${NC}"
fi

# ── Root check ─────────────────────────────────────────────────
[ "$(id -u)" -ne 0 ] && exec sudo bash "$0" "$@"

OUTPUT_DIR="$BUILD_DIR/output"
mkdir -p "$OUTPUT_DIR"
echo -e "${CYAN}[*] Build dir : $BUILD_DIR${NC}"
echo -e "${CYAN}[*] Output dir: $OUTPUT_DIR${NC}"

# ── Dependencies ───────────────────────────────────────────────
echo -e "${CYAN}[*] Installing build dependencies...${NC}"
apt-get update -qq
apt-get install -y --no-install-recommends \
    live-build debootstrap xorriso squashfs-tools \
    grub-pc-bin grub-efi-amd64-bin mtools \
    syslinux syslinux-common isolinux \
    rsync git curl wget ca-certificates \
    gnupg python3 python3-pip 2>/dev/null || true
echo -e "${GRN}[✓] Dependencies installed${NC}"

# ── Clean ──────────────────────────────────────────────────────
echo -e "${CYAN}[*] Cleaning previous build...${NC}"
lb clean --purge 2>/dev/null || true

# ── Configure ──────────────────────────────────────────────────
echo -e "${CYAN}[*] Configuring Shaurya OS...${NC}"
bash auto/config
echo -e "${GRN}[✓] Configuration OK${NC}"

# ── Build ──────────────────────────────────────────────────────
echo ""
echo -e "${ORAN}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${ORAN}║   BUILDING SHAURYA OS v1.0 — DO NOT INTERRUPT               ║${NC}"
echo -e "${ORAN}║   ⚔️  Courage in Every Byte — by Usman Ahmad                ║${NC}"
echo -e "${ORAN}║   Estimated time: 3-5 hours                                 ║${NC}"
echo -e "${ORAN}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""

START_T=$(date +%s)
lb build 2>&1 | tee "$OUTPUT_DIR/build.log"
END_T=$(date +%s)
ELAPSED=$(( END_T - START_T ))

# ── Find ISO ───────────────────────────────────────────────────
ISO_FILE=""
for pattern in "*.hybrid.iso" "live-image-amd64.hybrid.iso" "*.iso"; do
    found=$(find "$BUILD_DIR" -maxdepth 3 -name "$pattern" 2>/dev/null | head -1)
    [ -n "$found" ] && [ -s "$found" ] && { ISO_FILE="$found"; break; }
done

if [ -n "$ISO_FILE" ]; then
    DEST="$OUTPUT_DIR/Shaurya-OS-v1.0-amd64.hybrid.iso"
    [ "$ISO_FILE" != "$DEST" ] && cp "$ISO_FILE" "$DEST"

    echo ""
    echo -e "${ORAN}╔══════════════════════════════════════════════════════════════╗"
    echo -e "║      ⚔️  SHAURYA OS v1.0 — BUILD COMPLETE!                  ║"
    echo -e "╚══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "  ${GRN}✓ ISO    :${NC} $DEST"
    echo -e "  ${GRN}✓ Size   :${NC} $(du -sh "$DEST" | awk '{print $1}')"
    echo -e "  ${GRN}✓ MD5    :${NC} $(md5sum "$DEST" | awk '{print $1}')"
    echo -e "  ${GRN}✓ Time   :${NC} ${ELAPSED}s ($(( ELAPSED/60 )) min)"
    echo ""
    echo -e "  ${YLW}LOGIN CREDENTIALS:${NC}"
    echo -e "  ${CYAN}  Username : shaurya${NC}"
    echo -e "  ${CYAN}  Password : usman141093${NC}"
    echo ""
    echo -e "  ${YLW}Boot in VM:${NC}"
    echo -e "    qemu-system-x86_64 -m 4096 -enable-kvm -cdrom $DEST -boot d"
    echo ""
    echo -e "  ${YLW}Write to USB:${NC}"
    echo -e "    sudo dd if=$DEST of=/dev/sdX bs=4M status=progress oflag=sync"
    echo ""
    [ -n "$DISPLAY" ] && xdg-open "$OUTPUT_DIR/" 2>/dev/null &
    exit 0
else
    echo ""
    echo -e "${RED}╔══════════════════════════════════════════════════════════════╗"
    echo -e "║  BUILD FAILED — Check: $OUTPUT_DIR/build.log              ║"
    echo -e "╚══════════════════════════════════════════════════════════════╝${NC}"
    tail -30 "$OUTPUT_DIR/build.log" 2>/dev/null
    exit 1
fi

#!/bin/bash
# Shaurya OS v1.0 — Quick Start
# Created by: Usman Ahmad
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" 2>/dev/null && pwd)"
cd "$SCRIPT_DIR"

# Handle spaces in path
if echo "$(pwd)" | grep -q ' '; then
    SAFE="/tmp/shaurya-build"
    rm -rf "$SAFE"
    cp -r "$(pwd)" "$SAFE"
    cd "$SAFE"
fi

[ "$(id -u)" -ne 0 ] && exec sudo bash "$(pwd)/START.sh" "$@"

echo "[*] Starting Shaurya OS v1.0 build..."
chmod +x BUILD.sh auto/config 2>/dev/null || true
find config/hooks -name "*.chroot" -exec chmod +x {} \; 2>/dev/null || true

apt-get update -qq
apt-get install -y --no-install-recommends \
    live-build debootstrap xorriso squashfs-tools \
    grub-pc-bin grub-efi-amd64-bin mtools \
    syslinux syslinux-common isolinux \
    rsync git curl wget ca-certificates \
    gnupg python3 python3-pip 2>/dev/null || true

bash BUILD.sh "$@"

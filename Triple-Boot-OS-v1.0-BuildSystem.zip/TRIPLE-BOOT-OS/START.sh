#!/bin/bash
# ╔══════════════════════════════════════════════════════════════════╗
# ║  TRIPLE BOOT OS v1.0 — Master Build Script                    ║
# ║  Builds: Shaurya OS + Al-Hind OS + ANON-IRAN OS               ║
# ║  Default Boot: Shaurya OS v1.0                                 ║
# ║  Created by: Usman Ahmad                                        ║
# ╚══════════════════════════════════════════════════════════════════╝

set -e
RED='\033[0;31m'; GRN='\033[0;32m'; YLW='\033[1;33m'
ORAN='\033[0;33m'; CYAN='\033[0;36m'; NC='\033[0m'

echo -e "${CYAN}"
cat << 'BANNER'
  ████████╗██████╗ ██╗██████╗ ██╗     ███████╗
     ██╔══╝██╔══██╗██║██╔══██╗██║     ██╔════╝
     ██║   ██████╔╝██║██████╔╝██║     █████╗
     ██║   ██╔══██╗██║██╔═══╝ ██║     ██╔══╝
     ██║   ██║  ██║██║██║     ███████╗███████╗
     ╚═╝   ╚═╝  ╚═╝╚═╝╚═╝     ╚══════╝╚══════╝

  ██████╗  ██████╗  ██████╗ ████████╗
  ██╔══██╗██╔═══██╗██╔═══██╗╚══██╔══╝
  ██████╔╝██║   ██║██║   ██║   ██║
  ██╔══██╗██║   ██║██║   ██║   ██║
  ██████╔╝╚██████╔╝╚██████╔╝   ██║
  ╚═════╝  ╚═════╝  ╚═════╝    ╚═╝
BANNER
echo -e "${YLW}  ⚔️  Shaurya OS | 🇮🇳 Al-Hind OS | ☠️  ANON-IRAN OS${NC}"
echo -e "${CYAN}  Created by Usman Ahmad — Triple Boot v1.0${NC}"
echo ""

# ── Path fix ───────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" 2>/dev/null && pwd)"
cd "$SCRIPT_DIR"
BUILD_DIR="$(pwd)"

# Fix spaces in path
if echo "$BUILD_DIR" | grep -q ' '; then
    echo -e "${ORAN}[!] Space in path detected — copying to /tmp/triple-boot${NC}"
    SAFE="/tmp/triple-boot"
    rm -rf "$SAFE"
    cp -r "$BUILD_DIR" "$SAFE"
    cd "$SAFE"
    BUILD_DIR="$(pwd)"
    echo -e "${GRN}[✓] Safe path: $BUILD_DIR${NC}"
fi

# Root check
[ "$(id -u)" -ne 0 ] && exec sudo bash "$0" "$@"

OUTPUT_DIR="$BUILD_DIR/output"
mkdir -p "$OUTPUT_DIR"

echo -e "${CYAN}[*] Build dir : $BUILD_DIR${NC}"
echo -e "${CYAN}[*] Output dir: $OUTPUT_DIR${NC}"
echo ""

# ── Install dependencies ───────────────────────────────────────
echo -e "${CYAN}[*] Installing build dependencies...${NC}"
apt-get update -qq 2>/dev/null
apt-get install -y --no-install-recommends \
    live-build debootstrap xorriso squashfs-tools \
    grub-pc-bin grub-efi-amd64-bin mtools \
    syslinux syslinux-common isolinux \
    rsync git curl wget ca-certificates \
    gnupg python3 python3-pip 2>/dev/null || true
echo -e "${GRN}[✓] Dependencies installed${NC}"

# ── Clean previous build ───────────────────────────────────────
echo -e "${CYAN}[*] Cleaning previous build...${NC}"
lb clean --purge 2>/dev/null || true

# ── Configure ──────────────────────────────────────────────────
echo -e "${CYAN}[*] Configuring Triple Boot OS...${NC}"
bash auto/config
echo -e "${GRN}[✓] Configuration OK${NC}"

# ── Build ──────────────────────────────────────────────────────
echo ""
echo -e "${ORAN}╔══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${ORAN}║   BUILDING TRIPLE BOOT OS — DO NOT INTERRUPT                ║${NC}"
echo -e "${ORAN}║   ⚔️  Shaurya OS | 🇮🇳 Al-Hind OS | ☠️  ANON-IRAN OS        ║${NC}"
echo -e "${ORAN}║   Estimated time: 3-5 hours                                 ║${NC}"
echo -e "${ORAN}╚══════════════════════════════════════════════════════════════╝${NC}"
echo ""

START_T=$(date +%s)
lb build 2>&1 | tee "$OUTPUT_DIR/build.log"
END_T=$(date +%s)
ELAPSED=$(( END_T - START_T ))

# ── Find ISO ───────────────────────────────────────────────────
ISO_FILE=""
for pattern in "*.hybrid.iso" "*.iso"; do
    found=$(find "$BUILD_DIR" -maxdepth 3 -name "$pattern" 2>/dev/null | head -1)
    [ -n "$found" ] && [ -s "$found" ] && { ISO_FILE="$found"; break; }
done

if [ -n "$ISO_FILE" ]; then
    DEST="$OUTPUT_DIR/Triple-Boot-OS-v1.0-amd64.hybrid.iso"
    [ "$ISO_FILE" != "$DEST" ] && cp "$ISO_FILE" "$DEST"

    echo ""
    echo -e "${ORAN}╔══════════════════════════════════════════════════════════════╗"
    echo -e "║      TRIPLE BOOT OS v1.0 — BUILD COMPLETE! ⚔️               ║"
    echo -e "╚══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo -e "  ${GRN}✓ ISO    :${NC} $DEST"
    echo -e "  ${GRN}✓ Size   :${NC} $(du -sh "$DEST" | awk '{print $1}')"
    echo -e "  ${GRN}✓ MD5    :${NC} $(md5sum "$DEST" | awk '{print $1}')"
    echo -e "  ${GRN}✓ Time   :${NC} ${ELAPSED}s ($(( ELAPSED/60 )) min)"
    echo ""
    echo -e "  ${YLW}BOOT MENU (Shaurya OS = DEFAULT, 10s timeout):${NC}"
    echo -e "  ${CYAN}  ⚔️  Shaurya OS v1.0     shaurya / usman141093${NC}"
    echo -e "  ${CYAN}  🇮🇳  Al-Hind OS v1.0    al-hind / AlHind@007${NC}"
    echo -e "  ${CYAN}  ☠️   ANON-IRAN OS v7.0  anon-iran / AnonIran@007${NC}"
    echo ""
    echo -e "  ${YLW}Write to USB:${NC}"
    echo -e "    sudo dd if=$DEST of=/dev/sdX bs=4M status=progress"
    echo ""
    echo -e "  ${YLW}Boot in VM:${NC}"
    echo -e "    qemu-system-x86_64 -m 4096 -enable-kvm -cdrom $DEST -boot d"
    echo ""
else
    echo ""
    echo -e "${RED}╔══════════════════════════════════════════════════════════════╗"
    echo -e "║  BUILD FAILED — Check log: $OUTPUT_DIR/build.log          ║"
    echo -e "╚══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    echo "Last 20 lines of build log:"
    tail -20 "$OUTPUT_DIR/build.log" 2>/dev/null
    exit 1
fi

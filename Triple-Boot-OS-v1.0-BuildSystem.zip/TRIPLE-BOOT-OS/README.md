# ⚔️ Triple Boot OS v1.0
### Shaurya OS + Al-Hind OS + ANON-IRAN OS — by Usman Ahmad

---

## 🚀 What is Triple Boot OS?

One single bootable ISO that contains **3 complete security operating systems**.
At startup, a GRUB menu lets you choose which OS to boot.

```
╔══════════════════════════════════════════════════════════════════════╗
║                                                                      ║
║          ⚔️  TRIPLE BOOT OS — by Usman Ahmad                        ║
║                                                                      ║
╠══════════════════════════════════════════════════════════════════════╣
║                                                                      ║
║   [1] ⚔️  Shaurya OS v1.0    ← DEFAULT (boots in 10 seconds)       ║
║       user: shaurya  |  pass: usman141093                           ║
║       "Courage in Every Byte"                                        ║
║                                                                      ║
║   [2] 🇮🇳  Al-Hind OS v1.0                                          ║
║       user: al-hind  |  pass: AlHind@007                            ║
║       "Ultimate Security Platform"                                   ║
║                                                                      ║
║   [3] ☠️  ANON-IRAN OS v7.0                                         ║
║       user: anon-iran  |  pass: AnonIran@007                        ║
║       "Ghost in the Machine"                                         ║
║                                                                      ║
║   [4] 💾  Boot from Hard Disk                                        ║
║                                                                      ║
╚══════════════════════════════════════════════════════════════════════╝
```

---

## 📋 OS Credentials

| OS | Username | Password | Theme |
|---|---|---|---|
| ⚔️ Shaurya OS v1.0 | `shaurya` | `usman141093` | Cyan/Blue |
| 🇮🇳 Al-Hind OS v1.0 | `al-hind` | `AlHind@007` | Saffron/Green |
| ☠️ ANON-IRAN OS v7.0 | `anon-iran` | `AnonIran@007` | Dark/Red |

---

## 🛠️ Build Instructions

### Requirements
- Debian 12 / Ubuntu 22.04+ (or WSL2)
- 8 GB RAM (16 GB recommended)
- 40 GB free disk space
- Internet connection
- 3-5 hours build time

### Build Steps

```bash
# 1. Extract
unzip Triple-Boot-OS-v1.0-BuildSystem.zip

# 2. Build
cd TRIPLE-BOOT-OS
bash START.sh

# 3. ISO saved to:
# TRIPLE-BOOT-OS/output/Triple-Boot-OS-v1.0-amd64.hybrid.iso

# 4. Write to USB
sudo dd if=output/Triple-Boot-OS-v1.0-amd64.hybrid.iso \
    of=/dev/sdX bs=4M status=progress

# 5. Boot and select OS from menu!
```

### Windows (WSL2)
```bash
# Open WSL2 terminal:
cd /mnt/c/Users/YourName/
unzip Triple-Boot-OS-v1.0-BuildSystem.zip
cd TRIPLE-BOOT-OS && bash START.sh
```

---

## ⚙️ Features

### All 3 OS include:
- ✅ 10,000+ security tools pre-installed
- ✅ 500+ AI agents (AutoGPT, CrewAI, Ollama)
- ✅ Auto-Pwn Engine: `autopwn <target>`
- ✅ Web Dashboard: `http://localhost:8008`
- ✅ Android Security Toolkit
- ✅ Digital Forensics tools
- ✅ Cloud Security tools
- ✅ Self-Healing System

### Triple Boot extras:
- ✅ Unified `tools` command works across all OS
- ✅ `triple-boot-menu` shows all OS info
- ✅ GRUB menu with 10-second timeout
- ✅ Shaurya OS boots by default
- ✅ All 3 users created automatically

---

## 🔑 Key Commands

```bash
triple-boot-menu    # Show all OS info and credentials
tools               # Unified tool launcher
reboot              # Return to OS selection menu

# Shaurya OS
shaurya-autopwn <ip>    # Auto-Pwn attack chain
shaurya-menu            # Full tool menu

# Al-Hind OS
alhind-autopwn <ip>     # Auto-Pwn attack chain
alhind-menu             # Full tool menu
```

---

## 📞 Contact

**Created by:** Usman Ahmad
**Email:** ua6248634@gmail.com

---
*Triple Boot OS v1.0 — One ISO, Three OS, Infinite Possibilities*
